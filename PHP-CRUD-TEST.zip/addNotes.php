<?php
	session_start();
	include_once('connection.php');

	if(isset($_POST['add'])){
		$customer_id = $_POST['customer_id'];
		$notes = $_POST['notes'];
		
		$sql = "select * from notes where customer_id = '$customer_id' ";
		
		
		if(mysqli_num_rows($conn->query($sql))){
			
			$sql = "Update notes Set notes='$notes' where customer_id = '$customer_id'";

			//use for MySQLi OOP
			if($conn->query($sql)){
				$_SESSION['success'] = 'Notes  Updated successfully';
			}else{
				$_SESSION['error'] = 'Something went wrong while adding';
			}
			
		}else{
		
			$sql = "INSERT INTO notes (notes, customer_id) VALUES ('$notes', '$customer_id')";

			//use for MySQLi OOP
			if($conn->query($sql)){
				$_SESSION['success'] = 'Notes  added successfully';
			}else{
				$_SESSION['error'] = 'Something went wrong while adding';
			}
		}
		///////////////

		//use for MySQLi Procedural
		// if(mysqli_query($conn, $sql)){
		// 	$_SESSION['success'] = 'Member added successfully';
		// }
		//////////////
		
		
	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: index.php');
?>